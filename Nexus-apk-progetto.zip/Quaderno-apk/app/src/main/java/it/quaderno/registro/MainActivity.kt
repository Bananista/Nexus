package it.quaderno.registro

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

// Due WebView sovrapposte:
//  - ui: l'app Quaderno (il tuo layout)
//  - mc: la pagina di Mastercom; si vede solo per il login, poi resta nascosta
//        e da sola legge i dati, che vengono passati a ui.
class MainActivity : Activity() {
    private val mastercom = "https://marconi-fc.registroelettronico.com/mastercom/index.php"
    private lateinit var ui: WebView
    private lateinit var mc: WebView
    private var ultimo = 0L

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = WebView(this)
        mc = WebView(this)
        val root = FrameLayout(this)
        root.addView(ui)
        root.addView(mc)
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)
        for (w in listOf(ui, mc)) {
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.addJavascriptInterface(Ponte(), "Ponte")
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.url?.let { loader.shouldInterceptRequest(it) }
        }
        mc.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(script(), null)
            }
        }
        ui.loadUrl("https://appassets.androidplatform.net/assets/quaderno.html")
        aggiorna(true)
    }

    private fun aggiorna(mostra: Boolean) {
        ultimo = System.currentTimeMillis()
        mc.visibility = if (mostra) View.VISIBLE else View.INVISIBLE
        mc.loadUrl(mastercom)
    }

    override fun onResume() {
        super.onResume()
        // Quando riapri l'app, se sono passati più di 10 minuti, aggiorna i dati in silenzio.
        if (System.currentTimeMillis() - ultimo > 10 * 60 * 1000) aggiorna(false)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (mc.visibility == View.VISIBLE && mc.canGoBack()) mc.goBack() else super.onBackPressed()
    }

    // Codice che gira dentro la pagina di Mastercom: se c'è il login lo segnala,
    // altrimenti legge tutti i dati e li passa all'app.
    private fun script(): String {
        val lettore = assets.open("mastercom-reader.js").bufferedReader().use { it.readText() }
        return """
        (function(){
          if (window.__q) return; window.__q = 1;
          if (!window.MastercomReader) { window.MastercomReader = (function(){
            $lettore
            return MastercomReader; })(); }
          (async function(){
            try {
              const p = document.querySelector('input[type=password]');
              if (p && p.offsetParent !== null) { Ponte.serveLogin(); return; }
              let ok = false;
              for (let i = 0; i < 40 && !ok; i++) {
                const d = MastercomReader.diagnosi(); ok = d.current_user && d.current_key;
                if (!ok) await new Promise(function(r){ setTimeout(r, 500); });
              }
              if (!ok) { Ponte.serveLogin(); return; }
              Ponte.datiPronti(await MastercomReader.esporta());
            } catch (e) { Ponte.errore(String(e)); }
          })();
        })();
        """
    }

    inner class Ponte {
        @JavascriptInterface
        fun serveLogin() = runOnUiThread { mc.visibility = View.VISIBLE }

        @JavascriptInterface
        fun datiPronti(json: String) = runOnUiThread {
            mc.visibility = View.INVISIBLE
            ui.evaluateJavascript("Quaderno.importa(" + JSONObject.quote(json) + ");Quaderno.entra();", null)
        }

        @JavascriptInterface
        fun errore(messaggio: String) = runOnUiThread {
            mc.visibility = View.INVISIBLE
            Toast.makeText(this@MainActivity, "Aggiornamento non riuscito", Toast.LENGTH_SHORT).show()
        }

        // Tasto "Esci": cancella l'accesso a Mastercom e i dati salvati e torna al login.
        @JavascriptInterface
        fun esci() = runOnUiThread {
            CookieManager.getInstance().removeAllCookies(null)
            ui.evaluateJavascript("localStorage.removeItem('quaderno-dati');", null)
            aggiorna(true)
        }
    }
}
