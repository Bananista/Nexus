// mastercom-reader.js  (v2)
// Si esegue DENTRO la pagina di Mastercom, dopo il login dell'utente.
// Le richieste partono dalla stessa origine: niente CORS, nessuna password gestita.

const MastercomReader = (() => {
  const BASE = "/mastercom/index.php";
  const API = "/next-api/v1/app_sito/studente_quaderno";
  const sessione = { current_user: null, current_key: null };

  // --- 1) Recupero dei valori di sessione -------------------------------
  // La pagina ogni pochi secondi chiede "aggiornamenti" con il token in
  // Authorization: lo intercettiamo. Il current_user lo prendiamo dai POST
  // della pagina oppure dal codice della pagina.
  (function intercetta() {
    const setH = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function (n, v) {
      if (String(n).toLowerCase() === "authorization" && v) sessione.current_key = v;
      return setH.apply(this, arguments);
    };
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (body) {
      try {
        const get = body instanceof FormData ? (k) => body.get(k)
          : typeof body === "string" ? (k) => new URLSearchParams(body).get(k) : null;
        if (get) {
          if (get("current_user")) sessione.current_user = get("current_user");
          if (get("current_key")) sessione.current_key = get("current_key");
        }
      } catch (_) {}
      return send.apply(this, arguments);
    };
  })();

  function cercaNellaPagina(nome) {
    const el = document.querySelector(`[name="${nome}"]`);
    if (el && el.value) return el.value;
    const m = document.documentElement.innerHTML.match(
      new RegExp(nome + `["']?\\s*[:=,]\\s*["']([^"']+)["']`));
    return m ? m[1] : null;
  }

  function leggiSessione() {
    for (const k of ["current_user", "current_key"]) {
      if (!sessione[k]) sessione[k] = cercaNellaPagina(k);
    }
    if (!sessione.current_user || !sessione.current_key) {
      throw new Error("Sessione non trovata: fai il login, poi naviga una pagina e riprova.");
    }
    return sessione;
  }

  // Dice cosa è stato trovato, senza mostrare i valori.
  const diagnosi = () => ({
    current_user: !!(sessione.current_user || cercaNellaPagina("current_user")),
    current_key: !!(sessione.current_key || cercaNellaPagina("current_key")),
  });

  // --- 2) Pagine HTML (voti, compiti, agenda...) ------------------------
  async function pagina(statoPrincipale, extra = {}) {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData(); // il sito invia multipart/form-data
    const campi = {
      form_stato: "studente", stato_principale: statoPrincipale, stato_secondario: "",
      permission: "", operazione: "", current_user, current_key,
      from_app: "", webview: "", header: "SI", ...extra,
    };
    for (const [k, v] of Object.entries(campi)) f.append(k, v);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    if (!r.ok) throw new Error("Errore di rete: " + r.status);
    return new DOMParser().parseFromString(await r.text(), "text/html");
  }

  const pulisci = (s) => (s || "").replace(/\s+/g, " ").trim();

  // --- 3) Voti: struttura vista nelle foto ------------------------------
  // "8-" vale 7,75 e "7+" vale 7,25. Con questa regola la media dei 15 voti
  // numerici torna 7,77 come sul sito. Le annotazioni ("+" da solo) -> null.
  function valoreNumerico(t) {
    const m = t.replace(",", ".").match(/^(\d+(?:\.\d+)?)\s*([+\-]?)$/);
    if (!m) return null;
    const base = parseFloat(m[1]);
    return m[2] === "-" ? base - 0.25 : m[2] === "+" ? base + 0.25 : base;
  }

  async function getVoti() {
    const doc = await pagina("voti", { filter_materia: "0", filter_tipo: "tutti" });
    const medie = {};
    doc.querySelectorAll(".xxxlarge").forEach((el) => {
      const etichetta = pulisci(el.nextElementSibling?.textContent);
      if (etichetta) medie[etichetta] = pulisci(el.textContent);
    });
    const voti = [...doc.querySelectorAll('tr[data-tipo="voto"]')].map((tr) => {
      const td = tr.querySelectorAll("td");
      const votoTesto = pulisci(td[0]?.querySelector("strong")?.textContent);
      const c = td[2]?.cloneNode(true);
      const materia = pulisci(c?.querySelector("strong")?.textContent);
      const docente = pulisci(c?.querySelector("i.small")?.textContent);
      const etichetta = pulisci(c?.querySelector("span.small")?.textContent);
      c?.querySelectorAll("strong,i.small,span.small,br").forEach((e) => e.remove());
      const numero = valoreNumerico(votoTesto);
      const iTag = td[1] ? td[1].querySelectorAll("i") : []; // [data, tipo]
      return {
        materiaId: tr.getAttribute("data-materia"),
        materia, docente, etichetta,
        voto: Number.isNaN(numero) ? null : numero,
        votoTesto,                                   // es. "+" per le annotazioni
        data: pulisci(iTag[0]?.textContent),
        tipo: pulisci(iTag[1]?.textContent),         // Scritto, Pratico, Nota didattica...
        nota: pulisci(c?.textContent).replace(/^-\s*/, ""),
      };
    });
    return { medie, voti };
  }

  // --- 4) Contatori delle novità (JSON): voti, agenda, messaggi... -------
  async function getAggiornamenti() {
    const { current_key } = leggiSessione();
    const r = await fetch(API + "/aggiornamenti", {
      credentials: "same-origin", headers: { Authorization: current_key },
    });
    if (!r.ok) throw new Error("Errore di rete: " + r.status);
    return r.json();
  }

  // --- 5) Aiuto per scoprire le altre pagine ----------------------------
  // Stampa in console SOLO il nome della pagina quando clicchi nel menu.
  function spia() {
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (body) {
      if (body instanceof FormData && body.get("stato_principale") !== null) {
        console.log("PAGINA:", body.get("stato_principale"),
          "| secondario:", body.get("stato_secondario"),
          "| operazione:", body.get("operazione"));
      }
      return send.apply(this, arguments);
    };
    console.log("Spia attiva: clicca Compiti, Agenda, Comunicazioni.");
  }

  // Pagine viste con la spia: "argomenti-compiti", "agenda", "messaggi", "home".
  // Restituisce l'HTML ripulito e accorciato di una pagina, per capirne la struttura.
  // Uso: copy(await MastercomReader.html("argomenti-compiti"))  poi incolla in chat.
  async function html(statoPrincipale, extra = {}, max = 6000) {
    const doc = await pagina(statoPrincipale, extra);
    doc.querySelectorAll("script,style,svg").forEach((e) => e.remove());
    return doc.body.innerHTML.replace(/\s+/g, " ").replace(/> </g, "><").slice(0, max);
  }

  // --- 6) Compiti e agenda: struttura vista nell'HTML delle pagine -------
  // Il giorno compare solo nella prima riga di ogni gruppo (rowspan): lo ricordiamo.
  function leggiGiorno(td) {
    const s = td.querySelectorAll("strong");
    const c = td.cloneNode(true);
    c.querySelectorAll("strong,br").forEach((e) => e.remove());
    return {
      dataTesto: pulisci(s[0]?.textContent),   // es. "6 novembre" (senza anno)
      giornoSettimana: pulisci(c.textContent), // es. "Venerdì"
      etichetta: pulisci(s[1]?.textContent),   // "OGGI", "DOMANI" o vuoto
    };
  }

  async function getCompiti(filtri = {}) {
    const doc = await pagina("argomenti-compiti",
      { filter_materia: "0", filter_tipo: "tutti", ...filtri }); // tipo: tutti | argomento | assegnazione
    let giorno = null;
    const voci = [];
    doc.querySelectorAll("table.table tbody tr").forEach((tr) => {
      const dTd = tr.querySelector("td.center");
      if (dTd) giorno = leggiGiorno(dTd);
      const cTd = tr.querySelector("td.border-left");
      if (!cTd || !giorno) return;
      const materia = pulisci(cTd.querySelector(":scope > strong")?.textContent);
      cTd.querySelectorAll("[data-type]").forEach((el) => {
        const casella = el.querySelector("input[type=checkbox]");
        const riga = pulisci(el.querySelector("i.text-gray.small")?.textContent); // "(12:10 - NOME)"
        const m = riga.match(/^\((\d{1,2}:\d{2})\s*-\s*(.+)\)$/);
        const c = el.cloneNode(true);
        c.querySelectorAll("label,span.text-gray,i,br").forEach((e) => e.remove());
        voci.push({
          ...giorno, materia,
          tipo: el.getAttribute("data-type"), // argomento | assegnazione
          id: (casella?.getAttribute("onchange") || "").match(/'(\d+)'/)?.[1] ?? null,
          fatto: casella ? casella.hasAttribute("checked") : null,
          inserito: pulisci(el.querySelector("span.text-gray i")?.textContent).replace(/^Inserito il\s*/i, ""),
          ora: m ? m[1] : "", docente: m ? m[2] : "",
          testo: pulisci(c.textContent),
        });
      });
    });
    return voci;
  }

  async function getAgenda(filtri = {}) {
    const doc = await pagina("agenda", { filter_tipo_agenda: "tutti", ...filtri }); // annotazione | evento
    const voci = [];
    doc.querySelectorAll("table.table tbody tr").forEach((tr) => {
      const dTd = tr.querySelector("td.center");
      if (!dTd) return;
      const giorno = leggiGiorno(dTd);
      tr.querySelectorAll("[data-type]").forEach((el) => {
        const c = el.cloneNode(true);
        const orari = c.querySelector(".right-align");
        const fine = pulisci(orari?.querySelector(".text-gray")?.textContent);
        orari?.querySelector(".text-gray")?.remove();
        const inizio = pulisci(orari?.textContent);
        orari?.remove();
        const titolo = pulisci(c.querySelector("strong")?.textContent);
        const autore = pulisci(c.querySelector("i.text-gray")?.textContent).replace(/^\(|\)$/g, "");
        c.querySelectorAll("strong,i,span,br").forEach((e) => e.remove());
        voci.push({
          ...giorno, tipo: el.getAttribute("data-type"), // annotazione | evento
          inizio, fine, titolo, descrizione: pulisci(c.textContent), autore,
        });
      });
    });
    return voci;
  }

  // Come spia(), ma mostra le richieste di rete (con i token oscurati).
  function spiaRete() {
    const mask = (u) => String(u).replace(/eyJ[\w.\-]+/g, "TOKEN");
    const open = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (m, u) {
      console.log("XHR", m, mask(u));
      return open.apply(this, arguments);
    };
    const f = window.fetch;
    window.fetch = function (u, o) {
      console.log("FETCH", (o && o.method) || "GET", mask((u && u.url) || u));
      return f.apply(this, arguments);
    };
    console.log("Spia rete attiva.");
  }

  // Replica il modulo nascosto del pulsante "Accedi a Messenger" (solo 4 campi)
  // e riassume la risposta senza mostrare token né codice della pagina.
  async function esploraModulo(statoPrincipale) {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData();
    f.append("stato_principale", statoPrincipale);
    f.append("form_stato", "studente");
    f.append("current_user", current_user);
    f.append("current_key", current_key);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    const t = await r.text();
    const mask = (s) => String(s || "").replace(/eyJ[\w.\-]+/g, "TOKEN");
    const doc = new DOMParser().parseFromString(t, "text/html");
    const risorse = [...doc.querySelectorAll("script[src],link[href],iframe[src],form[action]")]
      .map((e) => mask(e.getAttribute("src") || e.getAttribute("href") || e.getAttribute("action")));
    doc.querySelectorAll("script,style").forEach((e) => e.remove());
    return {
      stato: r.status, tipo: r.headers.get("content-type"), lunghezza: t.length,
      titolo: pulisci(doc.title), risorse,
      testo: mask(pulisci(doc.body?.textContent)).slice(0, 300),
    };
  }

  // Tutto in un colpo, pronto da incollare nell'app Quaderno.
  async function esporta() {
    const [v, c, a] = await Promise.all([getVoti(), getCompiti(), getAgenda()]);
    return JSON.stringify({ versione: 1, creato: new Date().toISOString(), medie: v.medie, voti: v.voti, compiti: c, agenda: a });
  }

  return { getVoti, getCompiti, getAgenda, esporta, getAggiornamenti, pagina, html, diagnosi, spia, spiaRete, esploraModulo };
})();
