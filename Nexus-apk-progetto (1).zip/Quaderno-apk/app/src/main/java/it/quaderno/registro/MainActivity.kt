package it.quaderno.registro

import android.annotation.SuppressLint
import android.app.Activity
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

// Due WebView sovrapposte:
//  - ui: l'app Nexus (il tuo layout)
//  - mc: la pagina di Mastercom; si vede solo se serve il login, poi resta nascosta
//        e da sola legge i dati, che vengono passati a ui.
// Le credenziali si salvano cifrate (chiave custodita da Android) e il login si rifà da solo.
class MainActivity : Activity() {
    private val mastercom = "https://marconi-fc.registroelettronico.com/mastercom/index.php"
    private lateinit var ui: WebView
    private lateinit var mc: WebView
    private var ultimo = 0L
    @Volatile private var daSalvare: Pair<String, String>? = null
    @Volatile private var autoTentati = 0
    private var cassaforte: SharedPreferences? = null

    private fun prefs(): SharedPreferences? {
        if (cassaforte == null) {
            cassaforte = try {
                val chiave = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
                EncryptedSharedPreferences.create(
                    "accesso", chiave, this,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (e: Exception) { null }
        }
        return cassaforte
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = WebView(this)
        mc = WebView(this)
        val root = FrameLayout(this)
        root.addView(ui)
        root.addView(mc)
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)
        for (w in listOf(ui, mc)) {
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.addJavascriptInterface(Ponte(), "Ponte")
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.url?.let { loader.shouldInterceptRequest(it) }
        }
        mc.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(script(), null)
            }
        }
        ui.loadUrl("https://appassets.androidplatform.net/assets/quaderno.html")
        aggiorna(true)
    }

    private fun aggiorna(mostra: Boolean) {
        ultimo = System.currentTimeMillis()
        mc.visibility = if (mostra) View.VISIBLE else View.INVISIBLE
        mc.loadUrl(mastercom)
    }

    override fun onResume() {
        super.onResume()
        // Se riapri l'app dopo più di 10 minuti, i dati si aggiornano in silenzio.
        if (System.currentTimeMillis() - ultimo > 10 * 60 * 1000) aggiorna(false)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (mc.visibility == View.VISIBLE && mc.canGoBack()) mc.goBack() else super.onBackPressed()
    }

    // Codice che gira dentro la pagina di Mastercom: se c'è il login lo compila da solo
    // (o registra quello che scrivi), altrimenti legge i dati e li passa all'app.
    private fun script(): String {
        val lettore = assets.open("mastercom-reader.js").bufferedReader().use { it.readText() }
        val p = prefs()
        val u = p?.getString("u", null)
        val pw = p?.getString("p", null)
        // un solo tentativo automatico per volta, così una password cambiata non crea cicli
        val cred = if (u != null && pw != null && autoTentati < 1)
            "{u:" + JSONObject.quote(u) + ",p:" + JSONObject.quote(pw) + "}" else "null"
        return """
        (function(){
          if (window.__q) return; window.__q = 1;
          var CRED = $cred;
          if (!window.MastercomReader) { window.MastercomReader = (function(){
            $lettore
            return MastercomReader; })(); }
          (async function(){
            try {
              const p = document.querySelector('input[type=password]');
              if (p && p.offsetParent !== null) {
                const campi = Array.prototype.filter.call(document.querySelectorAll('input'), function(i){
                  return i.offsetParent !== null && /^(text|email|tel|number|)${'$'}/i.test(i.type) && (p.compareDocumentPosition(i) & 2);
                });
                const u = campi[campi.length - 1];
                const imposta = function(el, v){
                  el.focus(); el.value = v;
                  el.dispatchEvent(new Event('input', {bubbles: true}));
                  el.dispatchEvent(new Event('change', {bubbles: true}));
                };
                if (CRED && u) {
                  imposta(u, CRED.u); imposta(p, CRED.p); Ponte.autoInviato();
                  const f = p.form;
                  let b = f && f.querySelector('button[type=submit],input[type=submit]');
                  if (!b) b = Array.prototype.find.call(document.querySelectorAll('button,input[type=button],input[type=submit],a'), function(e){
                    return /accedi|entra|login|invia/i.test((e.value || '') + ' ' + e.textContent);
                  });
                  if (b) b.click(); else if (f) f.submit();
                  return;
                }
                const salva = function(){ if (u && p.value) Ponte.salvaCredenziali(u.value, p.value); };
                document.addEventListener('click', salva, true);
                document.addEventListener('submit', salva, true);
                document.addEventListener('keydown', function(e){ if (e.key === 'Enter') salva(); }, true);
                Ponte.serveLogin(); return;
              }
              let ok = false;
              for (let i = 0; i < 40 && !ok; i++) {
                const d = MastercomReader.diagnosi(); ok = d.current_user && d.current_key;
                if (!ok) await new Promise(function(r){ setTimeout(r, 500); });
              }
              if (!ok) { Ponte.serveLogin(); return; }
              Ponte.datiPronti(await MastercomReader.esporta());
            } catch (e) { Ponte.errore(String(e)); }
          })();
        })();
        """
    }

    inner class Ponte {
        @JavascriptInterface
        fun serveLogin() = runOnUiThread { mc.visibility = View.VISIBLE }

        @JavascriptInterface
        fun autoInviato() { autoTentati++ }

        // Quello che scrivi nel login: resta in memoria e si salva solo se il login riesce.
        @JavascriptInterface
        fun salvaCredenziali(utente: String, password: String) {
            if (utente.isNotBlank() && password.isNotEmpty()) daSalvare = Pair(utente, password)
        }

        @JavascriptInterface
        fun datiPronti(json: String) = runOnUiThread {
            autoTentati = 0
            daSalvare?.let { (utente, password) ->
                val precedente = prefs()?.getString("u", null)
                prefs()?.edit()?.putString("u", utente)?.putString("p", password)?.apply()
                if (precedente != utente) {
                    Toast.makeText(this@MainActivity, "Accesso salvato in modo sicuro su questo telefono", Toast.LENGTH_LONG).show()
                }
            }
            daSalvare = null
            mc.visibility = View.INVISIBLE
            ui.evaluateJavascript("Quaderno.importa(" + JSONObject.quote(json) + ");Quaderno.entra();", null)
        }

        @JavascriptInterface
        fun errore(messaggio: String) = runOnUiThread {
            mc.visibility = View.INVISIBLE
            Toast.makeText(this@MainActivity, "Aggiornamento non riuscito", Toast.LENGTH_SHORT).show()
        }

        // Tasto "Esci": cancella accesso salvato, sessione e dati, e torna al login.
        @JavascriptInterface
        fun esci() = runOnUiThread {
            prefs()?.edit()?.clear()?.apply()
            daSalvare = null
            autoTentati = 0
            CookieManager.getInstance().removeAllCookies(null)
            ui.evaluateJavascript("localStorage.removeItem('quaderno-dati');", null)
            aggiorna(true)
        }
    }
}
