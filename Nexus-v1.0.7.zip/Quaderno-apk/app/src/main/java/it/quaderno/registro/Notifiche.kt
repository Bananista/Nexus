package it.quaderno.registro

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONObject

// Confronta i dati di Mastercom con quelli già visti e avvisa solo di quello che è nuovo.
object Notifiche {
    private const val CANALE = "novita"
    private val CATEGORIE = listOf("voti", "compiti", "agenda", "avvisi", "note", "assenze")
    private val TITOLI = mapOf(
        "voti" to "Nuovo voto", "compiti" to "Nuovo compito", "agenda" to "Novità in agenda",
        "avvisi" to "Nuova comunicazione", "note" to "Nuova nota", "assenze" to "Novità sulle assenze"
    )

    fun canale(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CANALE, "Novità da Mastercom", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    @Suppress("DEPRECATION")
    private fun costruttore(ctx: Context): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CANALE) else Notification.Builder(ctx)

    fun mostra(ctx: Context, id: Int, titolo: String, testo: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        canale(ctx)
        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent()
        val pi = PendingIntent.getActivity(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = costruttore(ctx)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(titolo)
            .setContentText(testo)
            .setStyle(Notification.BigTextStyle().bigText(testo))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    // notifica = false: aggiorna solo la "memoria" delle novità già viste, senza avvisare.
    fun elabora(ctx: Context, json: String, notifica: Boolean) {
        val sp = ctx.getSharedPreferences("nexus", Context.MODE_PRIVATE)
        val dati = try { JSONObject(json) } catch (e: Exception) { return }
        sp.edit().putString("ultimo_json", json).apply()
        val pref = try { JSONObject(sp.getString("notif", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

        val corr = LinkedHashMap<String, LinkedHashMap<String, String>>()
        fun add(cat: String, chiave: String, desc: String) { corr.getOrPut(cat) { LinkedHashMap() }[chiave] = desc }

        dati.optJSONArray("voti")?.let { a ->
            for (i in 0 until a.length()) {
                val v = a.getJSONObject(i)
                val materia = v.optString("materia")
                val desc = if (v.isNull("voto")) materia + ": " + v.optString("etichetta", "annotazione")
                           else materia + ": " + v.optString("votoTesto")
                add("voti", v.optString("materiaId") + "|" + v.optString("data") + "|" + v.optString("votoTesto") + "|" + v.optString("tipo"), desc)
            }
        }
        dati.optJSONArray("compiti")?.let { a ->
            for (i in 0 until a.length()) {
                val c = a.getJSONObject(i)
                if (c.optString("tipo") != "assegnazione") continue
                val id = c.optString("id").ifEmpty { (c.optString("dataTesto") + c.optString("testo")).hashCode().toString() }
                add("compiti", id, c.optString("materia") + ": " + c.optString("testo").take(90))
            }
        }
        dati.optJSONArray("agenda")?.let { a ->
            for (i in 0 until a.length()) {
                val e = a.getJSONObject(i)
                val cat = if (e.optString("tipo") == "evento") "avvisi" else "agenda"
                add(cat, e.optString("dataTesto") + "|" + e.optString("titolo"), e.optString("titolo").take(90))
            }
        }
        dati.optJSONArray("note")?.let { a ->
            for (i in 0 until a.length()) {
                val n = a.getJSONObject(i)
                add("note", n.optString("data") + "|" + n.optString("ora") + "|" + n.optString("testo").hashCode(), "Nota di " + n.optString("docente"))
            }
        }
        dati.optJSONObject("assenze")?.optJSONArray("righe")?.let { a ->
            for (i in 0 until a.length()) add("assenze", a.optString(i), "Nuova assenza: " + a.optString(i).take(80))
        }

        CATEGORIE.forEachIndexed { n, cat ->
            val mappa = corr[cat] ?: LinkedHashMap()
            val prima = sp.getStringSet("k_$cat", null)
            sp.edit().putStringSet("k_$cat", HashSet(mappa.keys)).apply()
            if (!notifica || prima == null || !pref.optBoolean(cat, true)) return@forEachIndexed
            val nuovi = mappa.filterKeys { it !in prima }.values.toList()
            if (nuovi.isEmpty()) return@forEachIndexed
            val base = TITOLI[cat] ?: "Novità"
            val titolo = if (nuovi.size > 1) base + " (" + nuovi.size + ")" else base
            val testo = if (nuovi.size == 1) nuovi[0]
                        else nuovi.take(3).joinToString("\n") + (if (nuovi.size > 3) "\n… e altre " + (nuovi.size - 3) else "")
            mostra(ctx, 100 + n, titolo, testo)
        }
    }
}
