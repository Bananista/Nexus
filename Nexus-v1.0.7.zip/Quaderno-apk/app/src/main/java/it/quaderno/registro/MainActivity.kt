package it.quaderno.registro

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Due WebView sovrapposte:
//  - ui: l'app Nexus (il tuo layout)
//  - mc: la pagina di Mastercom; si vede solo se serve il login, poi resta nascosta
//        e da sola legge i dati, che vengono passati a ui.
// In più, ogni 15 minuti circa un controllo in background cerca le novità e manda le notifiche.
class MainActivity : Activity() {
    private lateinit var ui: WebView
    private lateinit var mc: WebView
    private var ultimo = 0L
    private var applicato = ""
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var daSalvare: Pair<String, String>? = null
    @Volatile private var autoTentati = 0

    // Mentre l'app è aperta aggiorna i dati ogni 3 minuti (se non stai facendo il login).
    private val ciclo = object : Runnable {
        override fun run() {
            if (mc.visibility != View.VISIBLE) aggiorna(false)
            h.postDelayed(this, 180_000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = WebView(this)
        mc = WebView(this)
        val root = FrameLayout(this)
        root.addView(ui)
        root.addView(mc)
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)
        for (w in listOf(ui, mc)) {
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.addJavascriptInterface(Ponte(), "Ponte")
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.url?.let { loader.shouldInterceptRequest(it) }
            override fun onPageFinished(view: WebView?, url: String?) { applicaUltimo() }
        }
        mc.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(Mastercom.script(this@MainActivity, autoTentati < 1), null)
            }
        }
        ui.loadUrl("https://appassets.androidplatform.net/assets/quaderno.html")

        Notifiche.canale(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        pianifica()
        aggiorna(true)
    }

    private fun pianifica() {
        val vincoli = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val richiesta = PeriodicWorkRequest.Builder(ControlloWorker::class.java, 15, TimeUnit.MINUTES)
            .setConstraints(vincoli)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("controllo", ExistingPeriodicWorkPolicy.UPDATE, richiesta)
    }

    private fun aggiorna(mostra: Boolean) {
        ultimo = System.currentTimeMillis()
        mc.visibility = if (mostra) View.VISIBLE else View.INVISIBLE
        mc.loadUrl(Mastercom.URL)
    }

    // Mostra subito gli ultimi dati letti dal controllo in background.
    private fun applicaUltimo() {
        val j = getSharedPreferences("nexus", MODE_PRIVATE).getString("ultimo_json", null) ?: return
        if (j == applicato) return
        applicato = j
        ui.evaluateJavascript("try{Quaderno.importa(" + JSONObject.quote(j) + ");Quaderno.entra()}catch(e){}", null)
    }

    override fun onResume() {
        super.onResume()
        applicaUltimo()
        if (System.currentTimeMillis() - ultimo > 2 * 60 * 1000 && mc.visibility != View.VISIBLE) aggiorna(false)
        h.removeCallbacks(ciclo)
        h.postDelayed(ciclo, 180_000)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(ciclo)
        CookieManager.getInstance().flush()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (mc.visibility == View.VISIBLE && mc.canGoBack()) mc.goBack() else super.onBackPressed()
    }

    inner class Ponte {
        @JavascriptInterface
        fun serveLogin() = runOnUiThread { mc.visibility = View.VISIBLE }

        @JavascriptInterface
        fun autoInviato() { autoTentati++ }

        // Quello che scrivi nel login: resta in memoria e si salva solo se il login riesce.
        @JavascriptInterface
        fun salvaCredenziali(utente: String, password: String) {
            if (utente.isNotBlank() && password.isNotEmpty()) daSalvare = Pair(utente, password)
        }

        @JavascriptInterface
        fun datiPronti(json: String) = runOnUiThread {
            autoTentati = 0
            daSalvare?.let { (utente, password) ->
                val acc = Mastercom.accesso(this@MainActivity)
                val precedente = acc?.getString("u", null)
                acc?.edit()?.putString("u", utente)?.putString("p", password)?.apply()
                if (precedente != utente) {
                    Toast.makeText(this@MainActivity, "Accesso salvato in modo sicuro su questo telefono", Toast.LENGTH_LONG).show()
                }
            }
            daSalvare = null
            Notifiche.elabora(this@MainActivity, json, false)   // aggiorna la memoria delle novità senza avvisare
            applicato = json
            mc.visibility = View.INVISIBLE
            ui.evaluateJavascript("Quaderno.importa(" + JSONObject.quote(json) + ");Quaderno.entra();", null)
        }

        @JavascriptInterface
        fun errore(messaggio: String) = runOnUiThread {
            mc.visibility = View.INVISIBLE
            Toast.makeText(this@MainActivity, "Aggiornamento non riuscito", Toast.LENGTH_SHORT).show()
        }

        // Trascinando la pagina verso il basso: aggiorna i dati subito.
        @JavascriptInterface
        fun aggiornaOra() = runOnUiThread { if (mc.visibility != View.VISIBLE) aggiorna(false) }

        // Le categorie di notifiche scelte nel menu.
        @JavascriptInterface
        fun impostaNotifiche(json: String) {
            getSharedPreferences("nexus", MODE_PRIVATE).edit().putString("notif", json).apply()
        }

        @JavascriptInterface
        fun provaNotifica() {
            Notifiche.mostra(this@MainActivity, 99, "Nexus", "Le notifiche funzionano correttamente.")
        }

        // Tasto "Esci": cancella accesso salvato, sessione e dati, e torna al login.
        @JavascriptInterface
        fun esci() = runOnUiThread {
            Mastercom.accesso(this@MainActivity)?.edit()?.clear()?.apply()
            getSharedPreferences("nexus", MODE_PRIVATE).edit().clear().apply()
            daSalvare = null
            autoTentati = 0
            applicato = ""
            CookieManager.getInstance().removeAllCookies(null)
            ui.evaluateJavascript("localStorage.removeItem('quaderno-dati');", null)
            aggiorna(true)
        }
    }
}
