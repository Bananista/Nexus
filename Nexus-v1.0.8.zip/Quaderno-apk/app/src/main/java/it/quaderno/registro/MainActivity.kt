package it.quaderno.registro

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Due WebView sovrapposte:
//  - ui: l'app Nexus (schermata di accesso, caricamento e tutto il resto)
//  - mc: la pagina di Mastercom, sempre nascosta: fa il login e legge i dati al posto tuo.
//        Si mostra solo se tocchi "Apri la pagina di Mastercom" dopo un accesso fallito.
// In più, ogni 15 minuti circa un controllo in background cerca le novità e manda le notifiche.
class MainActivity : Activity() {
    private lateinit var ui: WebView
    private lateinit var mc: WebView
    private var ultimo = 0L
    private var applicato = ""
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var daSalvare: Pair<String, String>? = null
    @Volatile private var autoTentati = 0

    private fun haCred(): Boolean = Mastercom.accesso(this)?.getString("u", null) != null
    private fun puoAggiornare(): Boolean = haCred() || applicato.isNotEmpty()

    // Mentre l'app è aperta aggiorna i dati ogni 3 minuti (se hai già fatto l'accesso).
    private val ciclo = object : Runnable {
        override fun run() {
            if (mc.visibility != View.VISIBLE && puoAggiornare()) aggiorna()
            h.postDelayed(this, 180_000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = WebView(this)
        mc = WebView(this)
        mc.visibility = View.INVISIBLE
        val root = FrameLayout(this)
        root.addView(ui)
        root.addView(mc)
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)
        for (w in listOf(ui, mc)) {
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.addJavascriptInterface(Ponte(), "Ponte")
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.url?.let { loader.shouldInterceptRequest(it) }
            override fun onPageFinished(view: WebView?, url: String?) { applicaUltimo() }
        }
        mc.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val primo = autoTentati < 1
                view?.evaluateJavascript(Mastercom.script(this@MainActivity, primo, if (primo) daSalvare else null), null)
            }
        }
        ui.loadUrl("https://appassets.androidplatform.net/assets/quaderno.html")

        Notifiche.canale(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        pianifica()
        aggiorna()
    }

    private fun pianifica() {
        val vincoli = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val richiesta = PeriodicWorkRequest.Builder(ControlloWorker::class.java, 15, TimeUnit.MINUTES)
            .setConstraints(vincoli)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("controllo", ExistingPeriodicWorkPolicy.UPDATE, richiesta)
    }

    private fun aggiorna() {
        ultimo = System.currentTimeMillis()
        mc.loadUrl(Mastercom.URL)
    }

    // Mostra subito gli ultimi dati letti dal controllo in background.
    private fun applicaUltimo() {
        val j = getSharedPreferences("nexus", MODE_PRIVATE).getString("ultimo_json", null) ?: return
        if (j == applicato) return
        applicato = j
        ui.evaluateJavascript("try{Quaderno.importa(" + JSONObject.quote(j) + ");Quaderno.entra()}catch(e){}", null)
    }

    override fun onResume() {
        super.onResume()
        applicaUltimo()
        if (System.currentTimeMillis() - ultimo > 2 * 60 * 1000 && mc.visibility != View.VISIBLE && puoAggiornare()) aggiorna()
        h.removeCallbacks(ciclo)
        h.postDelayed(ciclo, 180_000)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(ciclo)
        CookieManager.getInstance().flush()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (mc.visibility == View.VISIBLE) {
            if (mc.canGoBack()) mc.goBack() else mc.visibility = View.INVISIBLE
        } else super.onBackPressed()
    }

    inner class Ponte {
        // La pagina di Mastercom mostra il login e non possiamo compilarlo: lo dice all'app.
        @JavascriptInterface
        fun serveLogin() = runOnUiThread {
            if (mc.visibility == View.VISIBLE) return@runOnUiThread   // accesso manuale in corso
            val fallito = autoTentati >= 1
            if (fallito) {
                Mastercom.accesso(this@MainActivity)?.edit()?.clear()?.apply()
                daSalvare = null
            }
            ui.evaluateJavascript("Quaderno.serveLogin(" + fallito + ")", null)
        }

        @JavascriptInterface
        fun autoInviato() { autoTentati++ }

        // Quello che scrivi nel login manuale: resta in memoria e si salva solo se il login riesce.
        @JavascriptInterface
        fun salvaCredenziali(utente: String, password: String) {
            if (utente.isNotBlank() && password.isNotEmpty()) daSalvare = Pair(utente, password)
        }

        @JavascriptInterface
        fun datiPronti(json: String) = runOnUiThread {
            autoTentati = 0
            daSalvare?.let { (utente, password) ->
                val acc = Mastercom.accesso(this@MainActivity)
                val precedente = acc?.getString("u", null)
                acc?.edit()?.putString("u", utente)?.putString("p", password)?.apply()
                if (precedente != utente) {
                    Toast.makeText(this@MainActivity, "Accesso salvato in modo sicuro su questo telefono", Toast.LENGTH_LONG).show()
                }
            }
            daSalvare = null
            Notifiche.elabora(this@MainActivity, json, false)   // aggiorna la memoria delle novità senza avvisare
            applicato = json
            mc.visibility = View.INVISIBLE
            ui.evaluateJavascript("Quaderno.importa(" + JSONObject.quote(json) + ");Quaderno.entra();", null)
        }

        @JavascriptInterface
        fun errore(messaggio: String) = runOnUiThread {
            mc.visibility = View.INVISIBLE
            ui.evaluateJavascript("Quaderno.errore(" + JSONObject.quote("Aggiornamento non riuscito. Riprovo più tardi.") + ")", null)
        }

        // La schermata di accesso dell'app: i dati vengono inseriti nella pagina di Mastercom nascosta.
        @JavascriptInterface
        fun accedi(utente: String, password: String) = runOnUiThread {
            daSalvare = Pair(utente.trim(), password)
            autoTentati = 0
            mc.visibility = View.INVISIBLE
            aggiorna()
        }

        @JavascriptInterface
        fun haCredenziali(): Boolean = haCred()

        // Se l'accesso automatico non funziona: mostra la pagina di Mastercom per entrare a mano.
        @JavascriptInterface
        fun mostraMastercom() = runOnUiThread {
            mc.visibility = View.VISIBLE
            mc.loadUrl(Mastercom.URL)
        }

        // Trascinando la pagina verso il basso: aggiorna i dati subito.
        @JavascriptInterface
        fun aggiornaOra() = runOnUiThread { if (mc.visibility != View.VISIBLE && puoAggiornare()) aggiorna() }

        // Le categorie di notifiche scelte nel menu.
        @JavascriptInterface
        fun impostaNotifiche(json: String) {
            getSharedPreferences("nexus", MODE_PRIVATE).edit().putString("notif", json).apply()
        }

        @JavascriptInterface
        fun provaNotifica() {
            Notifiche.mostra(this@MainActivity, 99, "Nexus", "Le notifiche funzionano correttamente.")
        }

        // Data e esito dell'ultimo controllo in background.
        @JavascriptInterface
        fun statoControllo(): String = getSharedPreferences("nexus", MODE_PRIVATE).getString("stato_controllo", "") ?: ""

        // Chiede ad Android di non limitare l'app in background (più affidabile per le notifiche).
        @JavascriptInterface
        fun batteria() = runOnUiThread {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Non riesco ad aprire le impostazioni della batteria", Toast.LENGTH_SHORT).show()
            }
        }

        // Tasto "Esci": cancella accesso salvato, sessione e dati.
        @JavascriptInterface
        fun esci() = runOnUiThread {
            Mastercom.accesso(this@MainActivity)?.edit()?.clear()?.apply()
            getSharedPreferences("nexus", MODE_PRIVATE).edit().clear().apply()
            daSalvare = null
            autoTentati = 0
            applicato = ""
            CookieManager.getInstance().removeAllCookies(null)
            ui.evaluateJavascript("localStorage.removeItem('quaderno-dati');", null)
        }
    }
}
