package it.quaderno.registro

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import org.json.JSONObject

// Cose comuni all'app e al controllo in background.
object Mastercom {
    const val URL = "https://marconi-fc.registroelettronico.com/mastercom/index.php"
    @Volatile private var cassaforte: SharedPreferences? = null

    // Credenziali cifrate con una chiave custodita da Android (Keystore).
    fun accesso(ctx: Context): SharedPreferences? {
        if (cassaforte == null) {
            cassaforte = try {
                val chiave = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
                EncryptedSharedPreferences.create(
                    "accesso", chiave, ctx.applicationContext,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (e: Exception) { null }
        }
        return cassaforte
    }

    // Codice che gira dentro la pagina di Mastercom: compila il login (se ci sono credenziali
    // salvate), altrimenti legge tutti i dati e li passa al ponte "Ponte".
    fun script(ctx: Context, usaCredenziali: Boolean, provvisorie: Pair<String, String>? = null): String {
        val lettore = ctx.assets.open("mastercom-reader.js").bufferedReader().use { it.readText() }
        val p = accesso(ctx)
        val u = p?.getString("u", null)
        val pw = p?.getString("p", null)
        val cred = when {
            provvisorie != null -> "{u:" + JSONObject.quote(provvisorie.first) + ",p:" + JSONObject.quote(provvisorie.second) + "}"
            usaCredenziali && u != null && pw != null -> "{u:" + JSONObject.quote(u) + ",p:" + JSONObject.quote(pw) + "}"
            else -> "null"
        }
        return """
        (function(){
          if (window.__q) return; window.__q = 1;
          var CRED = $cred;
          if (!window.MastercomReader) { window.MastercomReader = (function(){
            $lettore
            return MastercomReader; })(); }
          (async function(){
            try {
              const p = document.querySelector('input[type=password]');
              if (p && p.offsetParent !== null) {
                const campi = Array.prototype.filter.call(document.querySelectorAll('input'), function(i){
                  return i.offsetParent !== null && /^(text|email|tel|number|)${'$'}/i.test(i.type) && (p.compareDocumentPosition(i) & 2);
                });
                const u = campi[campi.length - 1];
                const imposta = function(el, v){
                  el.focus(); el.value = v;
                  el.dispatchEvent(new Event('input', {bubbles: true}));
                  el.dispatchEvent(new Event('change', {bubbles: true}));
                };
                if (CRED && u) {
                  imposta(u, CRED.u); imposta(p, CRED.p); Ponte.autoInviato();
                  const f = p.form;
                  let b = f && f.querySelector('button[type=submit],input[type=submit]');
                  if (!b) b = Array.prototype.find.call(document.querySelectorAll('button,input[type=button],input[type=submit],a'), function(e){
                    return /accedi|entra|login|invia/i.test((e.value || '') + ' ' + e.textContent);
                  });
                  if (b) b.click(); else if (f) f.submit();
                  return;
                }
                const salva = function(){ if (u && p.value) Ponte.salvaCredenziali(u.value, p.value); };
                document.addEventListener('click', salva, true);
                document.addEventListener('submit', salva, true);
                document.addEventListener('keydown', function(e){ if (e.key === 'Enter') salva(); }, true);
                Ponte.serveLogin(); return;
              }
              let ok = false;
              for (let i = 0; i < 40 && !ok; i++) {
                const d = MastercomReader.diagnosi(); ok = d.current_user && d.current_key;
                if (!ok) await new Promise(function(r){ setTimeout(r, 500); });
              }
              if (!ok) { Ponte.serveLogin(); return; }
              Ponte.datiPronti(await MastercomReader.esporta());
            } catch (e) { Ponte.errore(String(e)); }
          })();
        })();
        """
    }
}
