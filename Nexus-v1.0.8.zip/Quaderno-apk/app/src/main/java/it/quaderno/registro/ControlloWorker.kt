package it.quaderno.registro

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.concurrent.futures.CallbackToFutureAdapter
import androidx.work.ListenableWorker
import androidx.work.WorkerParameters
import com.google.common.util.concurrent.ListenableFuture

// Parte da sola ogni 15 minuti circa (il minimo concesso da Android).
class ControlloWorker(ctx: Context, params: WorkerParameters) : ListenableWorker(ctx, params) {
    override fun startWork(): ListenableFuture<Result> =
        CallbackToFutureAdapter.getFuture<Result> { completer ->
            Handler(Looper.getMainLooper()).post {
                ControlloMastercom(applicationContext) { ok ->
                    completer.set(if (ok) Result.success() else Result.retry())
                }.avvia()
            }
            "controllo-mastercom"
        }
}
