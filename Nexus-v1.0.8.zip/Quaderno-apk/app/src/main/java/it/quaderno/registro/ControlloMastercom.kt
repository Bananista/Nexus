package it.quaderno.registro

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

// Apre Mastercom in una WebView nascosta, fa il login con le credenziali salvate,
// legge i dati e avvisa delle novità. Serve anche quando l'app è chiusa.
class ControlloMastercom(private val ctx: Context, private val fine: (Boolean) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var wv: WebView? = null
    private var finito = false
    private var inviati = 0

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    fun avvia() {
        val w = WebView(ctx)
        wv = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        w.addJavascriptInterface(Ponte(), "Ponte")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(Mastercom.script(ctx, true), null)
            }
        }
        w.loadUrl(Mastercom.URL)
        main.postDelayed({ termina(false, "tempo scaduto") }, 90_000)
    }

    private fun termina(ok: Boolean, nota: String = "") {
        if (finito) return
        finito = true
        val ora = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.ITALY).format(java.util.Date())
        ctx.getSharedPreferences("nexus", Context.MODE_PRIVATE).edit()
            .putString("stato_controllo", ora + " · " + (if (nota.isNotEmpty()) nota else if (ok) "ok" else "errore")).apply()
        wv?.destroy()
        wv = null
        fine(ok)
    }

    inner class Ponte {
        @JavascriptInterface fun serveLogin() { main.post { termina(true, "serve accedere di nuovo") } }
        @JavascriptInterface fun autoInviato() { inviati++; if (inviati > 2) main.post { termina(true) } }
        @JavascriptInterface fun salvaCredenziali(utente: String, password: String) {}
        @JavascriptInterface fun datiPronti(json: String) {
            Notifiche.elabora(ctx, json, true)
            main.post { termina(true) }
        }
        @JavascriptInterface fun errore(messaggio: String) { main.post { termina(false) } }
    }
}
