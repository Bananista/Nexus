// mastercom-reader.js  (v2)
// Si esegue DENTRO la pagina di Mastercom, dopo il login dell'utente.
// Le richieste partono dalla stessa origine: niente CORS, nessuna password gestita.

const MastercomReader = (() => {
  const BASE = "/mastercom/index.php";
  const API = "/next-api/v1/app_sito/studente_quaderno";
  const sessione = { current_user: null, current_key: null };

  // --- 1) Recupero dei valori di sessione -------------------------------
  // La pagina ogni pochi secondi chiede "aggiornamenti" con il token in
  // Authorization: lo intercettiamo. Il current_user lo prendiamo dai POST
  // della pagina oppure dal codice della pagina.
  (function intercetta() {
    const setH = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function (n, v) {
      if (String(n).toLowerCase() === "authorization" && v) sessione.current_key = v;
      return setH.apply(this, arguments);
    };
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (body) {
      try {
        const get = body instanceof FormData ? (k) => body.get(k)
          : typeof body === "string" ? (k) => new URLSearchParams(body).get(k) : null;
        if (get) {
          if (get("current_user")) sessione.current_user = get("current_user");
          if (get("current_key")) sessione.current_key = get("current_key");
        }
      } catch (_) {}
      return send.apply(this, arguments);
    };
  })();

  function cercaNellaPagina(nome) {
    const el = document.querySelector(`[name="${nome}"]`);
    if (el && el.value) return el.value;
    const m = document.documentElement.innerHTML.match(
      new RegExp(nome + `["']?\\s*[:=,]\\s*["']([^"']+)["']`));
    return m ? m[1] : null;
  }

  function leggiSessione() {
    for (const k of ["current_user", "current_key"]) {
      if (!sessione[k]) sessione[k] = cercaNellaPagina(k);
    }
    if (!sessione.current_user || !sessione.current_key) {
      throw new Error("Sessione non trovata: fai il login, poi naviga una pagina e riprova.");
    }
    return sessione;
  }

  // Dice cosa è stato trovato, senza mostrare i valori.
  const diagnosi = () => ({
    current_user: !!(sessione.current_user || cercaNellaPagina("current_user")),
    current_key: !!(sessione.current_key || cercaNellaPagina("current_key")),
  });

  // --- 2) Pagine HTML (voti, compiti, agenda...) ------------------------
  async function pagina(statoPrincipale, extra = {}) {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData(); // il sito invia multipart/form-data
    const campi = {
      form_stato: "studente", stato_principale: statoPrincipale, stato_secondario: "",
      permission: "", operazione: "", current_user, current_key,
      from_app: "", webview: "", header: "SI", ...extra,
    };
    for (const [k, v] of Object.entries(campi)) f.append(k, v);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    if (!r.ok) throw new Error("Errore di rete: " + r.status);
    return new DOMParser().parseFromString(await r.text(), "text/html");
  }

  const pulisci = (s) => (s || "").replace(/\s+/g, " ").trim();

  // --- 3) Voti: struttura vista nelle foto ------------------------------
  // "8-" vale 7,75 e "7+" vale 7,25. Con questa regola la media dei 15 voti
  // numerici torna 7,77 come sul sito. Le annotazioni ("+" da solo) -> null.
  function valoreNumerico(t) {
    const m = t.replace(",", ".").match(/^(\d+(?:\.\d+)?)\s*([+\-]?)$/);
    if (!m) return null;
    const base = parseFloat(m[1]);
    return m[2] === "-" ? base - 0.25 : m[2] === "+" ? base + 0.25 : base;
  }

  async function getVoti() {
    const doc = await pagina("voti", { filter_materia: "0", filter_tipo: "tutti" });
    const medie = {};
    doc.querySelectorAll(".xxxlarge").forEach((el) => {
      const etichetta = pulisci(el.nextElementSibling?.textContent);
      if (etichetta) medie[etichetta] = pulisci(el.textContent);
    });
    const voti = [...doc.querySelectorAll('tr[data-tipo="voto"]')].map((tr) => {
      const td = tr.querySelectorAll("td");
      const votoTesto = pulisci(td[0]?.querySelector("strong")?.textContent);
      const c = td[2]?.cloneNode(true);
      const materia = pulisci(c?.querySelector("strong")?.textContent);
      const docente = pulisci(c?.querySelector("i.small")?.textContent);
      const etichetta = pulisci(c?.querySelector("span.small")?.textContent);
      c?.querySelectorAll("strong,i.small,span.small,br").forEach((e) => e.remove());
      const numero = valoreNumerico(votoTesto);
      const iTag = td[1] ? td[1].querySelectorAll("i") : []; // [data, tipo]
      return {
        materiaId: tr.getAttribute("data-materia"),
        materia, docente, etichetta,
        voto: Number.isNaN(numero) ? null : numero,
        votoTesto,                                   // es. "+" per le annotazioni
        data: pulisci(iTag[0]?.textContent),
        tipo: pulisci(iTag[1]?.textContent),         // Scritto, Pratico, Nota didattica...
        nota: pulisci(c?.textContent).replace(/^-\s*/, ""),
      };
    });
    return { medie, voti };
  }

  // --- 4) Contatori delle novità (JSON): voti, agenda, messaggi... -------
  async function getAggiornamenti() {
    const { current_key } = leggiSessione();
    const r = await fetch(API + "/aggiornamenti", {
      credentials: "same-origin", headers: { Authorization: current_key },
    });
    if (!r.ok) throw new Error("Errore di rete: " + r.status);
    return r.json();
  }

  // --- 5) Aiuto per scoprire le altre pagine ----------------------------
  // Stampa in console SOLO il nome della pagina quando clicchi nel menu.
  function spia() {
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (body) {
      if (body instanceof FormData && body.get("stato_principale") !== null) {
        console.log("PAGINA:", body.get("stato_principale"),
          "| secondario:", body.get("stato_secondario"),
          "| operazione:", body.get("operazione"));
      }
      return send.apply(this, arguments);
    };
    console.log("Spia attiva: clicca Compiti, Agenda, Comunicazioni.");
  }

  // Pagine viste con la spia: "argomenti-compiti", "agenda", "messaggi", "home".
  // Restituisce l'HTML ripulito e accorciato di una pagina, per capirne la struttura.
  // Uso: copy(await MastercomReader.html("argomenti-compiti"))  poi incolla in chat.
  async function html(statoPrincipale, extra = {}, max = 6000) {
    const doc = await pagina(statoPrincipale, extra);
    doc.querySelectorAll("script,style,svg").forEach((e) => e.remove());
    return doc.body.innerHTML.replace(/\s+/g, " ").replace(/> </g, "><").slice(0, max);
  }

  // --- 6) Compiti e agenda: struttura vista nell'HTML delle pagine -------
  // Il giorno compare solo nella prima riga di ogni gruppo (rowspan): lo ricordiamo.
  function leggiGiorno(td) {
    const s = td.querySelectorAll("strong");
    const c = td.cloneNode(true);
    c.querySelectorAll("strong,br").forEach((e) => e.remove());
    return {
      dataTesto: pulisci(s[0]?.textContent),   // es. "6 novembre" (senza anno)
      giornoSettimana: pulisci(c.textContent), // es. "Venerdì"
      etichetta: pulisci(s[1]?.textContent),   // "OGGI", "DOMANI" o vuoto
    };
  }

  async function getCompiti(filtri = {}) {
    const doc = await pagina("argomenti-compiti",
      { filter_materia: "0", filter_tipo: "tutti", ...filtri }); // tipo: tutti | argomento | assegnazione
    let giorno = null;
    const voci = [];
    doc.querySelectorAll("table.table tbody tr").forEach((tr) => {
      const dTd = tr.querySelector("td.center");
      if (dTd) giorno = leggiGiorno(dTd);
      const cTd = tr.querySelector("td.border-left");
      if (!cTd || !giorno) return;
      const materia = pulisci(cTd.querySelector(":scope > strong")?.textContent);
      cTd.querySelectorAll("[data-type]").forEach((el) => {
        const casella = el.querySelector("input[type=checkbox]");
        const riga = pulisci(el.querySelector("i.text-gray.small")?.textContent); // "(12:10 - NOME)"
        const m = riga.match(/^\((\d{1,2}:\d{2})\s*-\s*(.+)\)$/);
        const c = el.cloneNode(true);
        c.querySelectorAll("label,span.text-gray,i,br").forEach((e) => e.remove());
        voci.push({
          ...giorno, materia,
          tipo: el.getAttribute("data-type"), // argomento | assegnazione
          id: (casella?.getAttribute("onchange") || "").match(/'(\d+)'/)?.[1] ?? null,
          fatto: casella ? casella.hasAttribute("checked") : null,
          inserito: pulisci(el.querySelector("span.text-gray i")?.textContent).replace(/^Inserito il\s*/i, ""),
          ora: m ? m[1] : "", docente: m ? m[2] : "",
          testo: pulisci(c.textContent),
        });
      });
    });
    return voci;
  }

  async function getAgenda(filtri = {}) {
    const doc = await pagina("agenda", { filter_tipo_agenda: "tutti", ...filtri }); // annotazione | evento
    const voci = [];
    doc.querySelectorAll("table.table tbody tr").forEach((tr) => {
      const dTd = tr.querySelector("td.center");
      if (!dTd) return;
      const giorno = leggiGiorno(dTd);
      tr.querySelectorAll("[data-type]").forEach((el) => {
        const c = el.cloneNode(true);
        const orari = c.querySelector(".right-align");
        const fine = pulisci(orari?.querySelector(".text-gray")?.textContent);
        orari?.querySelector(".text-gray")?.remove();
        const inizio = pulisci(orari?.textContent);
        orari?.remove();
        const titolo = pulisci(c.querySelector("strong")?.textContent);
        const autore = pulisci(c.querySelector("i.text-gray")?.textContent).replace(/^\(|\)$/g, "");
        c.querySelectorAll("strong,i,span,br").forEach((e) => e.remove());
        voci.push({
          ...giorno, tipo: el.getAttribute("data-type"), // annotazione | evento
          inizio, fine, titolo, descrizione: pulisci(c.textContent), autore,
        });
      });
    });
    return voci;
  }

  // Come spia(), ma mostra le richieste di rete (con i token oscurati).
  function spiaRete() {
    const mask = (u) => String(u).replace(/eyJ[\w.\-]+/g, "TOKEN");
    const open = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (m, u) {
      console.log("XHR", m, mask(u));
      return open.apply(this, arguments);
    };
    const f = window.fetch;
    window.fetch = function (u, o) {
      console.log("FETCH", (o && o.method) || "GET", mask((u && u.url) || u));
      return f.apply(this, arguments);
    };
    console.log("Spia rete attiva.");
  }

  // Replica il modulo nascosto del pulsante "Accedi a Messenger" (solo 4 campi)
  // e riassume la risposta senza mostrare token né codice della pagina.
  async function esploraModulo(statoPrincipale) {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData();
    f.append("stato_principale", statoPrincipale);
    f.append("form_stato", "studente");
    f.append("current_user", current_user);
    f.append("current_key", current_key);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    const t = await r.text();
    const mask = (s) => String(s || "").replace(/eyJ[\w.\-]+/g, "TOKEN");
    const doc = new DOMParser().parseFromString(t, "text/html");
    const risorse = [...doc.querySelectorAll("script[src],link[href],iframe[src],form[action]")]
      .map((e) => mask(e.getAttribute("src") || e.getAttribute("href") || e.getAttribute("action")));
    doc.querySelectorAll("script,style").forEach((e) => e.remove());
    return {
      stato: r.status, tipo: r.headers.get("content-type"), lunghezza: t.length,
      titolo: pulisci(doc.title), risorse,
      testo: mask(pulisci(doc.body?.textContent)).slice(0, 300),
    };
  }

  // --- 7) Note disciplinari e orario di oggi (struttura vista con scopri) -----
  async function getNote() {
    const doc = await pagina("note-disciplinari");
    return [...doc.querySelectorAll(".panel .card.padding.round.margin-bottom")].map((el) => {
      const intest = el.querySelector(".right-align");
      const forti = intest ? intest.querySelectorAll("strong") : [];
      const interno = el.querySelector(".card");
      const c = interno ? interno.cloneNode(true) : null;
      c?.querySelector(".center")?.remove();
      return {
        data: pulisci(forti[0]?.textContent), ora: pulisci(forti[1]?.textContent),
        docente: pulisci((intest?.textContent || "").split("\u2192")[1]),
        tipo: pulisci(interno?.querySelector(".center strong")?.textContent),
        testo: pulisci(c?.textContent).replace(/^["\u201c]|["\u201d]$/g, ""),
      };
    });
  }

  // La scheda "Orario" della Home mostra le lezioni di OGGI.
  async function getOrarioOggi() {
    const doc = await pagina("home");
    const h4 = [...doc.querySelectorAll("h4")].find((h) => /orario/i.test(h.textContent));
    const lezioni = [];
    (h4 ? h4.parentElement : doc).querySelectorAll("tr").forEach((tr) => {
      const td = tr.querySelectorAll("td");
      if (td.length < 2 || !td[0].querySelector("strong")) return;
      const a = td[0].cloneNode(true);
      const ora = pulisci(a.querySelector("strong")?.textContent);
      a.querySelectorAll("strong,br").forEach((e) => e.remove());
      const b = td[1].cloneNode(true);
      const docente = pulisci(b.querySelector(".small")?.textContent);
      b.querySelectorAll(".small,br").forEach((e) => e.remove());
      lezioni.push({ ora, fine: pulisci(a.textContent), materia: pulisci(b.textContent), docente });
    });
    return { giorno: new Date().getDay(), lezioni }; // 0 = domenica ... 6 = sabato
  }

  // Per capire come Messenger legge i messaggi: elenco degli indirizzi e il punto
  // del codice che costruisce la richiesta. Uso: copy(await MastercomReader.scopriMessenger())
  async function scopriMessenger() {
    const out = [];
    for (const p of ["messenger.js", "messenger/messenger.js"]) {
      const t = await (await fetch("/mastercom/javascript/" + p + "?v=26.1.44")).text();
      const url = new Set();
      for (const m of t.matchAll(/\/messenger\/1\.0\/[A-Za-z0-9_\-\/{}?=&.]*/g)) url.add(m[0]);
      out.push("== " + p + " INDIRIZZI ==\n" + [...url].join("\n"));
      const i = t.indexOf("reduce_content");
      if (i >= 0) out.push("== " + p + " ELENCO MESSAGGI ==\n" + t.slice(Math.max(0, i - 1200), i + 2200).replace(/\s+/g, " "));
    }
    return out.join("\n\n").replace(/eyJ[\w.\-]+/g, "TOKEN");
  }

  // --- 7) Note disciplinari, assenze, orario di oggi (dalla pagina Home) ---
  async function getNoteDisciplinari() {
    const doc = await pagina("note-disciplinari");
    return [...doc.querySelectorAll("div.card.padding.round")].filter((e) => e.querySelector(".round-large")).map((el) => {
      const testa = el.firstElementChild;                 // "31/10/2026 ore 13:05 → DOCENTE"
      const forti = testa ? testa.querySelectorAll("strong") : [];
      const corpo = el.querySelector(".round-large");
      const c = corpo.cloneNode(true);
      c.querySelector(".center")?.remove();
      return {
        data: pulisci(forti[0]?.textContent),
        ora: pulisci(forti[1]?.textContent),
        docente: pulisci((testa?.textContent || "").split("→")[1]),
        titolo: pulisci(corpo.querySelector("strong")?.textContent), // es. "Nota disciplinare"
        testo: pulisci(c.textContent).replace(/^["“”«]+|["“”»]+$/g, ""),
      };
    });
  }

  async function getAssenze() {
    const doc = await pagina("assenze");
    const righe = [...doc.querySelectorAll("table tbody tr")];
    const vuoto = righe.length > 0 && righe.every((tr) => /nessuna assenza/i.test(tr.textContent));
    return { vuoto, righe: vuoto ? [] : righe.map((tr) => pulisci(tr.textContent)) };
  }

  // La scheda "Orario" della Home mostra le lezioni di OGGI.
  async function getOrarioOggi() {
    const doc = await pagina("home");
    const h4 = [...doc.querySelectorAll("h4")].find((e) => /^orario$/i.test(pulisci(e.textContent)));
    const box = h4 && h4.parentElement;
    if (!box) return [];
    return [...box.querySelectorAll("table tbody tr")].map((tr) => {
      const td = tr.querySelectorAll("td");
      const c0 = td[0]?.cloneNode(true);
      c0?.querySelector("strong")?.remove();
      const c1 = td[1]?.cloneNode(true);
      const docente = pulisci(c1?.querySelector("span.small")?.textContent);
      c1?.querySelector("span.small")?.remove();
      return { ora: pulisci(td[0]?.querySelector("strong")?.textContent), fine: pulisci(c0?.textContent), materia: pulisci(c1?.textContent), docente };
    }).filter((x) => x.ora && x.materia);
  }

  // Legge l'elenco "In arrivo" di Messenger (prima pagina) aprendolo in un riquadro invisibile.
  async function getMessaggi() {
    const { current_user, current_key } = leggiSessione();
    const ifr = document.createElement("iframe");
    ifr.name = "nx_msg2";
    ifr.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none";
    document.body.appendChild(ifr);
    const f = document.createElement("form");
    f.method = "POST"; f.action = BASE; f.target = "nx_msg2";
    for (const [k, v] of Object.entries({ stato_principale: "messenger", form_stato: "studente", current_user, current_key })) {
      const i = document.createElement("input"); i.type = "hidden"; i.name = k; i.value = v; f.appendChild(i);
    }
    document.body.appendChild(f);
    f.submit();
    const leggi = (tr) => {
      const td = [...tr.querySelectorAll("td")].map((x) => pulisci(x.textContent));
      const data = (tr.textContent.match(/\d{2}\/\d{2}\/\d{4}/) || [""])[0];
      const k = td.findIndex((t) => t.indexOf(data) >= 0 && t.length <= 14);
      const iData = k >= 0 ? k : td.length - 2;
      return {
        data,
        mittente: (td[iData - 2] || td[0] || "").replace(/\s+\d+$/, ""),
        oggetto: (td[iData - 1] || "").replace(/^\d+\s+/, ""),
        stato: td[iData + 1] || "",
      };
    };
    let righe = [], ultimoN = -1, stabile = 0;
    const t0 = Date.now();
    await new Promise((res) => {
      const iv = setInterval(() => {
        try {
          const d = ifr.contentDocument;
          const r = d ? [...d.querySelectorAll("tr")].filter((tr) => tr.querySelectorAll("td").length >= 3 && /\d{2}\/\d{2}\/\d{4}/.test(tr.textContent)) : [];
          if (r.length && r.length === ultimoN) stabile++; else stabile = 0;
          ultimoN = r.length;
          if (r.length) righe = r.map(leggi);
          if (stabile >= 2) { clearInterval(iv); res(); return; }
        } catch (_) {}
        if (Date.now() - t0 > 20000) { clearInterval(iv); res(); }
      }, 300);
    });
    ifr.remove(); f.remove();
    return righe.filter((m) => m.oggetto);
  }

  // Il nome compare nell'intestazione di Messenger ("☰ COGNOME NOME Messenger").
  async function getProfilo() {
    const { current_user, current_key } = leggiSessione();
    const f = new FormData();
    f.append("stato_principale", "messenger");
    f.append("form_stato", "studente");
    f.append("current_user", current_user);
    f.append("current_key", current_key);
    const r = await fetch(BASE, { method: "POST", credentials: "same-origin", body: f });
    const doc = new DOMParser().parseFromString(await r.text(), "text/html");
    doc.querySelectorAll("script,style").forEach((e) => e.remove());
    const m = pulisci(doc.body?.textContent).match(/☰\s*(.+?)\s+Messenger/);
    return { nome: m ? m[1] : "" };
  }

  // Tutto in un colpo, pronto da incollare nell'app Nexus.
  // Le parti facoltative, se falliscono, diventano null senza bloccare il resto.
  async function esporta() {
    const [v, c, a, n, s, p, m] = await Promise.all([
      getVoti(), getCompiti(), getAgenda(),
      getNoteDisciplinari().catch(() => null), getAssenze().catch(() => null), getProfilo().catch(() => null),
      getMessaggi().catch(() => null),
    ]);
    return JSON.stringify({ versione: 4, creato: new Date().toISOString(), medie: v.medie, voti: v.voti, compiti: c, agenda: a, note: n, assenze: s, profilo: p, messaggi: m });
  }

  // Raccoglie in un solo testo la struttura delle pagine che mancano
  // (orario, note disciplinari, assenze) e i punti del codice di Messenger che
  // leggono i messaggi. Uso: copy(await MastercomReader.scopri())
  async function scopri() {
    const mask = (s) => String(s).replace(/eyJ[\w.\-]+/g, "TOKEN");
    const pulito = (doc) => {
      doc.querySelectorAll("script,style,svg").forEach((e) => e.remove());
      return doc.body.innerHTML.replace(/\s+/g, " ").replace(/> </g, "><");
    };
    const out = [];
    const prova = async (nome, fn) => {
      try { out.push("=== " + nome + " ===\n" + mask(await fn())); }
      catch (e) { out.push("=== " + nome + " === ERRORE: " + e.message); }
    };
    await prova("HOME-ORARIO", async () => {
      const t = pulito(await pagina("home"));
      const i = t.search(/Orario/i);
      return i < 0 ? "Orario non trovato. Inizio pagina: " + t.slice(0, 1500) : t.slice(Math.max(0, i - 300), i + 3000);
    });
    await prova("NOTE-DISCIPLINARI", async () => pulito(await pagina("note-disciplinari")).slice(0, 5000));
    await prova("ASSENZE", async () => pulito(await pagina("assenze")).slice(0, 4000));
    await prova("MESSENGER-JS", async () => {
      const pezzi = [];
      for (const p of ["messenger.js", "messenger/messenger.js"]) {
        const t = await (await fetch("/mastercom/javascript/" + p + "?v=26.1.44")).text();
        const re = /1\.0\/messages|messaggistica\//g;
        let m, ultimo = -1000;
        while ((m = re.exec(t)) && pezzi.length < 14) {
          if (m.index - ultimo < 300) continue;
          ultimo = m.index;
          pezzi.push(p + "@" + m.index + ": " + t.slice(Math.max(0, m.index - 200), m.index + 300).replace(/\s+/g, " "));
        }
      }
      return pezzi.join("\n---\n");
    });
    return out.join("\n\n");
  }

  // Come scopri(), ma solo per i Messaggi: codice che legge l'elenco, il "canale"
  // e due prove di richiesta. Uso: copy(await MastercomReader.scopriMessenger())
  async function scopriMessenger() {
    const mask = (s) => String(s).replace(/eyJ[\w.\-]+/g, "TOKEN");
    const out = [];
    const prova = async (nome, fn) => {
      try { out.push("=== " + nome + " ===\n" + mask(await fn())); }
      catch (e) { out.push("=== " + nome + " === ERRORE: " + e.message); }
    };
    const js = {};
    for (const p of ["messenger.js", "messenger/messenger.js"]) {
      js[p] = await (await fetch("/mastercom/javascript/" + p + "?v=26.1.44")).text();
    }
    await prova("ELENCO-CODICE", async () => js["messenger.js"].slice(9800, 11800).replace(/\s+/g, " "));
    await prova("CANALE-CODICE", async () => {
      const pezzi = [];
      for (const p in js) {
        const re = /channelId\s*=|channel_id|\/channels|getChannel|my_channel/gi;
        let m, ult = -1000;
        while ((m = re.exec(js[p])) && pezzi.length < 8) {
          if (m.index - ult < 400) continue;
          ult = m.index;
          pezzi.push(p + "@" + m.index + ": " + js[p].slice(Math.max(0, m.index - 150), m.index + 350).replace(/\s+/g, " "));
        }
      }
      return pezzi.join("\n---\n");
    });
    for (const url of ["/messenger/1.0/messages?reduce_content=true&category=MESSAGE", "/messenger/1.0/messages"]) {
      await prova("PROVA " + url, async () => {
        const r = await fetch(url, { credentials: "same-origin" });
        return r.status + " " + (await r.text()).slice(0, 800);
      });
    }
    return out.join("\n\n");
  }

  // Apre Messenger in un riquadro invisibile, ascolta le richieste che la pagina fa da sola
  // e restituisce indirizzi e risposte (accorciate). Dura circa 12 secondi.
  // Uso: copy(await MastercomReader.scopriMessenger2())
  async function scopriMessenger2() {
    const { current_user, current_key } = leggiSessione();
    const mask = (s) => String(s).replace(/eyJ[\w.\-]+/g, "TOKEN");
    const catturati = [];
    const ifr = document.createElement("iframe");
    ifr.name = "nx_msg";
    ifr.style.cssText = "position:fixed;width:1px;height:1px;opacity:0;pointer-events:none";
    document.body.appendChild(ifr);
    const f = document.createElement("form");
    f.method = "POST"; f.action = BASE; f.target = "nx_msg";
    for (const [k, v] of Object.entries({ stato_principale: "messenger", form_stato: "studente", current_user, current_key })) {
      const i = document.createElement("input"); i.type = "hidden"; i.name = k; i.value = v; f.appendChild(i);
    }
    document.body.appendChild(f);
    f.submit();
    const t0 = Date.now();
    await new Promise((res) => {
      const iv = setInterval(() => {
        try {
          const w = ifr.contentWindow;
          if (w && w.jQuery && !w.__nx) {
            w.__nx = 1;
            w.jQuery(w.document).ajaxComplete((e, xhr, opt) => {
              catturati.push((opt.type || opt.method || "GET") + " " + opt.url + " -> " + xhr.status + " " +
                String(xhr.responseText || "").replace(/\s+/g, " ").slice(0, 1200));
            });
          }
        } catch (_) {}
        if (Date.now() - t0 > 12000) { clearInterval(iv); res(); }
      }, 40);
    });
    let testo = "";
    try {
      const c = ifr.contentDocument.body.cloneNode(true);
      c.querySelectorAll("script,style").forEach((e) => e.remove());
      testo = pulisci(c.textContent).slice(0, 1500);
    } catch (_) {}
    ifr.remove(); f.remove();
    return mask("=== RICHIESTE DI MESSENGER (" + catturati.length + ") ===\n" + catturati.join("\n---\n") + "\n\n=== TESTO DELLA PAGINA ===\n" + testo);
  }

  return { getProfilo, getVoti, getCompiti, getAgenda, esporta, scopri, scopriMessenger, getNoteDisciplinari, getAssenze, getOrarioOggi, getNote, getAggiornamenti, pagina, html, diagnosi, spia, spiaRete, esploraModulo, scopriMessenger2, getMessaggi };
})();
