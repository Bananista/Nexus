# Nexus (Quaderno)

App Android non ufficiale che raccoglie i dati del registro elettronico scolastico **Mastercom**
(voti, assenze, compiti, argomenti, comunicazioni) e li mostra in un'interfaccia semplice e veloce,
con **notifiche** in background sulle novità.

## Come funziona
- Due WebView sovrapposte: l'interfaccia dell'app e una pagina di Mastercom nascosta
  che effettua il login automatico e legge i dati (intercettando le risposte della pagina).
- Le credenziali vengono salvate cifrate sul dispositivo (`EncryptedSharedPreferences`)
  e usate solo per il login automatico; la password non viene mai salvata nell'interfaccia web.
- Un `WorkManager` esegue un controllo ogni ~15 minuti con rete disponibile e genera le notifiche
  per le categorie scelte (voti, assenze, note, compiti, ecc.).
- L'aggiornamento può essere forzato trascinando verso il basso.

## Build
1. Clona il repository
2. Apri la cartella in Android Studio (o usa la riga di comando)
3. `./gradlew assembleDebug` oppure usa la GitHub Action inclusa
   (`.github/workflows/apk.yml`) che compila l'APK automaticamente su ogni push su `main`
   e lo pubblica come artifact.

## Requisiti
- Android 7.0+ (API 24), target SDK 34
- Java 17

## Privacy e sicurezza
- Nessun dato lascia il telefono: niente server propri, niente analytics.
- Le notifiche richiedono il permesso Android; per un controllo affidabile in background
  l'app chiede di escluderla dalle ottimizzazioni batteria.

## Avvertenze
- Progetto personale/didattico, **non affiliato a Mastercom**.
- Mastercom potrebbe cambiare la struttura delle pagine: in quel caso il lettore
  (`mastercom-reader.js`) va aggiornato di conseguenza.

## Novità della 1.0.9
- Design rinnovato, solo tema scuro
- Caricamento semplice al posto della partita a scacchi
- Scorrimento laterale tra sezioni corretto
- Comunicazioni collegate a Messenger (con conteggi)
- Filtro per materia in Interrogazioni e Compiti
- Pagina Argomenti svolti nella sezione Compiti
- Pop-up delle novità dopo ogni aggiornamento

## Licenza
Da definire (es. MIT). Vedi il file `LICENSE`.
